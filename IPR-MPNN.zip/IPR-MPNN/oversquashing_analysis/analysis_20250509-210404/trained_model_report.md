# Oversquashing Analysis for MUTAG Models

Date: 2025-05-09 21:04:04

## Model Connectivity Analysis

| Dataset | Top-k | Model Type | Effective Resistance | Spectral Gap | Algebraic Connectivity | Clustering Coefficient |
|---------|-------|------------|----------------------|--------------|------------------------|------------------------|
