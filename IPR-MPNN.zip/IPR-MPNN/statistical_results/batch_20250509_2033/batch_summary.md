# Batch Statistical Experiment Results

Date: 2025-05-09 20:33:47

## Experiments

| Dataset | Top-k | Mean Balanced | Mean Uniform | p-value | Significant |
|---------|-------|---------------|--------------|---------|-------------|
| ENZYMES | 2 | 0.2444 | 0.2583 | 0.7458 | No |
| ENZYMES | 3 | 0.2417 | 0.2639 | 0.3190 | No |
| ENZYMES | 4 | 0.2361 | 0.2639 | 0.3288 | No |
| PROTEINS | 2 | 0.6966 | 0.6607 | 0.1201 | No |
| PROTEINS | 3 | 0.6876 | 0.6816 | 0.7943 | No |
| PROTEINS | 4 | 0.6876 | 0.6816 | 0.7943 | No |

## Summary

Total runtime: 0h 13m 39.19s
Completed 6 experiments
